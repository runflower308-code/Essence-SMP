ZIP THE CONTENTS OF THIS FOLDER, NOT THE FOLDER ITSELF. pack.mcmeta must be at the ZIP root.
Host the resulting ZIP at a direct HTTPS download URL and configure the server's resource-pack URL, SHA-1, and required-pack setting.
